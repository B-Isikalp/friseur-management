# Maison Élégance – Online-Terminplaner

Eine responsive Demo-Webseite für einen Friseursalon. Das Projekt verwendet HTML, CSS und JavaScript ohne zusätzliches Framework.

## Funktionen
- Responsive Startseite und Serviceübersicht
- Monatskalender mit auswählbaren Tagen
- Auswahl einer Dienstleistung und passender freier Zeitfenster
- Prüfung auf zeitliche Überschneidungen von Terminen
- Buchungsformular mit Pflichtfeldprüfung
- Terminübersicht und Stornierung
- Speicherung der Demo-Buchungen im `localStorage` des Browsers

## Projekt lokal starten
1. Repository herunterladen oder klonen.
2. `index.html` im Browser öffnen.
3. Für eine komfortablere Entwicklung kann die VS-Code-Erweiterung „Live Server“ verwendet werden.

## Veröffentlichung mit GitHub Pages
1. Dateien `index.html`, `style.css` und `script.js` in das Hauptverzeichnis des GitHub-Repositories hochladen.
2. Im Repository **Settings → Pages** öffnen.
3. Unter „Build and deployment“ die Quelle **Deploy from a branch** auswählen.
4. Branch `main` und Ordner `/ (root)` auswählen und speichern.
5. Nach der Veröffentlichung die angezeigte GitHub-Pages-Adresse öffnen.

## Technische Hinweise
Dies ist eine Frontend-Demo. Buchungen werden nur im lokalen Browser gespeichert. Sie werden nicht zwischen verschiedenen Geräten synchronisiert und es wird keine Bestätigungs-E-Mail versendet. Für einen echten Salonbetrieb werden ein Backend, eine zentrale Datenbank, serverseitige Verfügbarkeitsprüfung und ein datenschutzkonformes Berechtigungskonzept benötigt.

Die Servicebezeichnungen, Preise, Öffnungszeiten und geschlossenen Tage in `script.js` sind Beispieldaten und sollten vor einer Vorführung angepasst werden.
