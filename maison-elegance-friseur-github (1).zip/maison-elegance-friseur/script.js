const SERVICES = [
  { id: "cut", name: "Haircut & Styling", description: "Individueller Schnitt und ein gepflegtes Finish.", duration: 60, price: 65 },
  { id: "blowout", name: "Blowout", description: "Volumen, Bewegung und ein glänzendes Finish.", duration: 45, price: 40 },
  { id: "color", name: "Color & Glossing", description: "Frische Farbe und strahlender Glanz.", duration: 120, price: 145 },
  { id: "balayage", name: "Balayage", description: "Natürlich wirkende Highlights mit weichen Übergängen.", duration: 180, price: 220 },
  { id: "care", name: "Intensive Hair Treatment", description: "Pflege-Ritual für geschmeidiges, glänzendes Haar.", duration: 45, price: 55 },
  { id: "event", name: "Event Styling", description: "Ein besonderer Look für deinen besonderen Anlass.", duration: 75, price: 85 }
];

const STORAGE_KEY = "maisonEleganceAppointments";
const OPEN_HOUR = 9;
const CLOSE_HOUR = 18;
const SLOT_STEP = 30;
const CLOSED_DAYS = [0]; // Sonntag geschlossen
let viewDate = new Date();
let selectedDate = "";
let selectedTime = "";
let selectedService = SERVICES[0].id;

const $ = (id) => document.getElementById(id);
const money = (value) => new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(value);
const dateKey = (date) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;
const parseDate = (key) => { const [y,m,d] = key.split("-").map(Number); return new Date(y,m-1,d); };
const getAppointments = () => {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); }
  catch { return []; }
};
const saveAppointments = (items) => localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
const currentService = () => SERVICES.find(s => s.id === selectedService);

function renderServices() {
  $("serviceList").innerHTML = SERVICES.map((s, i) => `
    <article class="service-card">
      <span class="service-number">0${i+1}</span>
      <h3>${s.name}</h3>
      <p>${s.description}</p>
      <div class="service-meta"><span>${s.duration} Min.</span><strong>ab ${money(s.price)}</strong></div>
    </article>`).join("");
  $("serviceSelect").innerHTML = SERVICES.map(s => `<option value="${s.id}">${s.name} · ${s.duration} Min. · ${money(s.price)}</option>`).join("");
  $("serviceSelect").value = selectedService;
}

function renderCalendar() {
  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  $("monthLabel").textContent = new Intl.DateTimeFormat("de-DE", { month: "long", year: "numeric" }).format(viewDate);
  const firstDay = new Date(year, month, 1);
  const offset = (firstDay.getDay() + 6) % 7;
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date(); today.setHours(0,0,0,0);
  let html = "";
  for (let i=0; i<offset; i++) html += `<span></span>`;
  for (let day=1; day<=daysInMonth; day++) {
    const date = new Date(year, month, day);
    const key = dateKey(date);
    const disabled = date < today || CLOSED_DAYS.includes(date.getDay());
    const classes = ["day", key === selectedDate ? "selected" : "", key === dateKey(today) ? "today" : ""].filter(Boolean).join(" ");
    html += `<button class="${classes}" data-date="${key}" ${disabled ? "disabled" : ""} aria-label="${day}. ${$("monthLabel").textContent}">${day}</button>`;
  }
  $("calendarDays").innerHTML = html;
  $("calendarDays").querySelectorAll("[data-date]").forEach(btn => btn.addEventListener("click", () => {
    selectedDate = btn.dataset.date;
    selectedTime = "";
    renderCalendar(); renderTimeSlots(); updateSummary();
  }));
}

function overlaps(startA, durationA, startB, durationB) {
  return startA < startB + durationB && startB < startA + durationA;
}
function renderTimeSlots() {
  const host = $("timeSlots");
  if (!selectedDate) { host.innerHTML = '<p class="muted">Bitte wähle zuerst ein Datum.</p>'; return; }
  $("selectedDateLabel").textContent = new Intl.DateTimeFormat("de-DE", { day:"2-digit", month:"2-digit", year:"numeric" }).format(parseDate(selectedDate));
  const service = currentService();
  const appointments = getAppointments().filter(a => a.date === selectedDate);
  const now = new Date();
  const isToday = selectedDate === dateKey(now);
  const buttons = [];
  for (let mins = OPEN_HOUR*60; mins + service.duration <= CLOSE_HOUR*60; mins += SLOT_STEP) {
    const hour = Math.floor(mins/60), minute = mins%60;
    const label = `${String(hour).padStart(2,"0")}:${String(minute).padStart(2,"0")}`;
    const start = mins;
    const busy = appointments.some(a => {
      const [h,m] = a.time.split(":").map(Number);
      return overlaps(start, service.duration, h*60+m, a.duration);
    });
    const inPast = isToday && mins <= now.getHours()*60 + now.getMinutes();
    if (!busy && !inPast) buttons.push(`<button type="button" class="time-slot ${selectedTime===label ? "selected" : ""}" data-time="${label}">${label}</button>`);
  }
  host.innerHTML = buttons.length ? buttons.join("") : '<p class="muted">Für diesen Tag sind keine passenden Zeiten verfügbar.</p>';
  host.querySelectorAll("[data-time]").forEach(btn => btn.addEventListener("click", () => {
    selectedTime = btn.dataset.time; renderTimeSlots(); updateSummary();
  }));
}

function updateSummary() {
  const s = currentService();
  $("summaryService").textContent = s.name;
  $("summaryDuration").textContent = `${s.duration} Minuten`;
  $("summaryPrice").textContent = `ab ${money(s.price)}`;
  $("summaryDate").textContent = selectedDate && selectedTime
    ? `${new Intl.DateTimeFormat("de-DE").format(parseDate(selectedDate))} · ${selectedTime} Uhr`
    : "Noch nicht gewählt";
}

function renderAppointments() {
  const list = getAppointments().sort((a,b) => (a.date+a.time).localeCompare(b.date+b.time));
  const host = $("appointmentList");
  if (!list.length) { host.innerHTML = '<p class="muted">Noch keine Termine vorhanden.</p>'; return; }
  host.innerHTML = list.map(a => `
    <article class="appointment-item">
      <div>
        <h4>${escapeHtml(a.name)} · ${escapeHtml(a.serviceName)}</h4>
        <p>${new Intl.DateTimeFormat("de-DE", { dateStyle:"full" }).format(parseDate(a.date))} um ${escapeHtml(a.time)} Uhr · ${a.duration} Min. · ${money(a.price)}</p>
        <p>${escapeHtml(a.email)} · ${escapeHtml(a.phone)}</p>
      </div>
      <button class="cancel-button" data-cancel="${a.id}">Stornieren</button>
    </article>`).join("");
  host.querySelectorAll("[data-cancel]").forEach(btn => btn.addEventListener("click", () => {
    if (!confirm("Möchtest du diesen Demo-Termin wirklich stornieren?")) return;
    saveAppointments(getAppointments().filter(a => a.id !== btn.dataset.cancel));
    renderAppointments(); renderTimeSlots();
  }));
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
}

$("serviceSelect").addEventListener("change", (event) => {
  selectedService = event.target.value; selectedTime = "";
  renderTimeSlots(); updateSummary();
});
$("prevMonth").addEventListener("click", () => {
  const candidate = new Date(viewDate.getFullYear(), viewDate.getMonth()-1, 1);
  const today = new Date(); today.setDate(1); today.setHours(0,0,0,0);
  if (candidate >= today) { viewDate = candidate; renderCalendar(); }
});
$("nextMonth").addEventListener("click", () => {
  viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth()+1, 1); renderCalendar();
});
$("bookingForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const message = $("formMessage");
  const form = event.currentTarget;
  if (!selectedDate || !selectedTime) {
    message.textContent = "Bitte wähle zuerst ein Datum und eine Uhrzeit.";
    message.className = "form-message error"; return;
  }
  const service = currentService();
  // Verfügbarkeit beim Speichern erneut prüfen, damit keine Doppelbuchung im selben Browser entsteht.
  const start = Number(selectedTime.slice(0,2))*60 + Number(selectedTime.slice(3,5));
  const conflict = getAppointments().some(a => {
    if (a.date !== selectedDate) return false;
    const otherStart = Number(a.time.slice(0,2))*60 + Number(a.time.slice(3,5));
    return overlaps(start, service.duration, otherStart, a.duration);
  });
  if (conflict) {
    selectedTime = ""; renderTimeSlots(); updateSummary();
    message.textContent = "Diese Uhrzeit ist leider nicht mehr verfügbar. Bitte wähle eine andere.";
    message.className = "form-message error"; return;
  }
  const data = new FormData(form);
  const appointment = {
    id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
    name: data.get("name").trim(), email: data.get("email").trim(),
    phone: data.get("phone").trim(), note: data.get("note").trim(),
    serviceId: service.id, serviceName: service.name, duration: service.duration,
    price: service.price, date: selectedDate, time: selectedTime
  };
  if (!appointment.name || !appointment.email || !appointment.phone) {
    message.textContent = "Bitte fülle alle Pflichtfelder aus.";
    message.className = "form-message error"; return;
  }
  saveAppointments([...getAppointments(), appointment]);
  form.reset(); selectedDate = ""; selectedTime = "";
  message.textContent = "Dein Demo-Termin wurde in diesem Browser gespeichert. Es wurde keine echte Salonbuchung versendet.";
  message.className = "form-message success";
  renderCalendar(); renderTimeSlots(); updateSummary(); renderAppointments();
});
$("menuToggle").addEventListener("click", () => {
  const nav = $("mainNav"); const open = nav.classList.toggle("open");
  $("menuToggle").setAttribute("aria-expanded", String(open));
});
$("mainNav").querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  $("mainNav").classList.remove("open"); $("menuToggle").setAttribute("aria-expanded", "false");
}));

$("year").textContent = new Date().getFullYear();
renderServices(); renderCalendar(); renderTimeSlots(); updateSummary(); renderAppointments();
